import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# For reproducibility
np.random.seed(42)

# 1. Generate random scattered data with noise
N = 50
true_m = 2
true_c = 5

x = np.random.uniform(0, 10, N)  # scattered x-values
noise = np.random.normal(0, 4, N)  # Gaussian noise
y = true_m * x + true_c + noise

# Save to CSV
df = pd.DataFrame({'x': x, 'y': y})
df.to_csv('data.csv', index=False)

# 2. Gradient Descent to fit y = c + mx
m = 0
c = 0
alpha = 0.01
epochs = 2000

for _ in range(epochs):
    y_pred = m * x + c
    error = y_pred - y
    m_grad = (2/N) * np.dot(error, x)
    c_grad = (2/N) * np.sum(error)
    
    m -= alpha * m_grad
    c -= alpha * c_grad

print(f"Learned m: {m:.4f}")
print(f"Learned c: {c:.4f}")

# 3. Plot data and fitted line
plt.figure(figsize=(10, 6))
plt.scatter(x, y, color='purple', label='Data Points')
plt.plot(x, m * x + c, color='pink', linewidth=2, label='Fitted Line')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Linear Regression using Gradient Descent')
plt.legend()
plt.grid(True)
plt.show()
